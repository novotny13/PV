﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoffeeApp.Models
{
    [Table("types")]
    public class CoffeeType
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("type")]
        [Required]
        [MaxLength(50)]
        public string Type { get; set; }

        public ICollection<CoffeeLog> CoffeeLogs { get; set; }
    }
}
