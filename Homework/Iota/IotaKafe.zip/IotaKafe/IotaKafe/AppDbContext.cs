﻿using Microsoft.EntityFrameworkCore;
using CoffeeApp.Models;
using Task = CoffeeApp.Models.Task;
using UserTask = CoffeeApp.Models.UserTask;


namespace CoffeeApp.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<CoffeeLog> CoffeeLogs { get; set; }
        public DbSet<CoffeeType> CoffeeTypes { get; set; }
        public DbSet<Task> Tasks { get; set; }
        public DbSet<UserTask> UserTasks { get; set; }
        public DbSet<Reward> Rewards { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            
            // Mapování existujících tabulek
            modelBuilder.Entity<User>().ToTable("users");
            modelBuilder.Entity<CoffeeLog>().ToTable("coffee_log");
            modelBuilder.Entity<CoffeeType>().ToTable("types");
            modelBuilder.Entity<Task>().ToTable("tasks");
            modelBuilder.Entity<UserTask>().ToTable("user_task");
            modelBuilder.Entity<Reward>().ToTable("rewards");

            // Konfigurace složeného klíče pro tabulku user_task
            modelBuilder.Entity<UserTask>()
                .HasKey(ut => new { ut.UserId, ut.TaskId });
            

            // Konfigurace relací pro UserTask
            modelBuilder.Entity<UserTask>()
                .HasOne(ut => ut.User)
                .WithMany(u => u.UserTasks)
                .HasForeignKey(ut => ut.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<UserTask>()
                .HasOne(ut => ut.Task)
                .WithMany(t => t.UserTasks)
                .HasForeignKey(ut => ut.TaskId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
