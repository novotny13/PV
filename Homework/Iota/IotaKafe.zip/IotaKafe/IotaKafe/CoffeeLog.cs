﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoffeeApp.Models
{
    [Table("coffee_log")]
    public class CoffeeLog
    {
        [Key]
        [Column("log_id")]
        public int LogId { get; set; }

        [Column("user_id")]
        [Required]
        public int UserId { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }

        [Column("amount")]
        [Required]
        public int Amount { get; set; }

        [Column("timestamp")]
        public DateTime Timestamp { get; set; } = DateTime.Now;

        [Column("type_id")]
        [Required]
        public int TypeId { get; set; }

        [ForeignKey("TypeId")]
        public CoffeeType Type { get; set; }

        [Column("milk")]
        [MaxLength(5)]
        public string Milk { get; set; }

        [Column("sugar")]
        [MaxLength(5)]
        public string Sugar { get; set; }
    }
}
