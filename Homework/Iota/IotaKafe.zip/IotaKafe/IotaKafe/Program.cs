using System;
using System.Linq;
using CoffeeApp.Data;
using CoffeeApp.Models;
using CoffeeApp.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

class Program
{
    static AppDbContext _dbContext;
    static UserService _userService;
    static CoffeeLogService _coffeeLogService;

    static void Main(string[] args)
    {
        // Na��t�n� konfigura�n�ho souboru appsettings.json
        var configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory()) // Nastaven� z�kladn� cesty pro na��t�n�
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        // Na��t�n� p�ipojovac�ho �et�zce
        var connectionString = configuration.GetConnectionString("DefaultConnection");

        // Nastaven� datab�zov�ho kontextu pomoc� p�ipojovac�ho �et�zce
        var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
        optionsBuilder.UseSqlServer(connectionString); // Pou�it� SQL Serveru pro p�ipojen�

        _dbContext = new AppDbContext(optionsBuilder.Options);
        _userService = new UserService(_dbContext);
        _coffeeLogService = new CoffeeLogService(_dbContext);
        
        while (true)
        {
            
            Console.WriteLine("1. P�ihl�sit se");
            Console.WriteLine("2. Zaregistrovat se");
            Console.WriteLine("3. Konec");
            Console.Write("Vyberte mo�nost: ");
            var choice = Console.ReadLine();

            if (choice == "1")
            {
                LoginMenu();
            }
            else if (choice == "2")
            {
                RegisterMenu();
            }
            else if (choice == "3")
            {
                break; // Ukon�� aplikaci
            }
        }
    }

    // Menu pro registraci
    static void RegisterMenu()
    {
        Console.Clear();
        Console.WriteLine("Zaregistrujte se:");
        Console.Write("Zadejte u�ivatelsk� jm�no: ");
        var username = Console.ReadLine();
        Console.Write("Zadejte heslo: ");
        var password = Console.ReadLine();

        if (_userService.RegisterUser(username, password))
        {
            Console.WriteLine("Registrace prob�hla �sp�n�!");
        }
        else
        {
            Console.WriteLine("U�ivatelsk� jm�no ji� existuje.");
        }

        Console.WriteLine("Stiskn�te libovolnou kl�vesu pro n�vrat.");
        Console.ReadKey();
    }

    // Menu pro p�ihl�en�
    static void LoginMenu()
    {
        Console.Clear();
        Console.WriteLine("P�ihl�en�:");
        Console.Write("Zadejte u�ivatelsk� jm�no: ");
        string username = Console.ReadLine();
        Console.Write("Zadejte heslo: ");
        var password = Console.ReadLine();

        var user = _userService.LoginUser(username, password);
        
        if (user != null)
        {
            Console.WriteLine("P�ihl�en� �sp�n�!");
            MainUserMenu(user);
        }
        else
        {
            Console.WriteLine("Neplatn� u�ivatelsk� jm�no nebo heslo.");
        }

        Console.WriteLine("Stiskn�te libovolnou kl�vesu pro n�vrat.");
        Console.ReadKey();
    }

    // Hlavn� menu po p�ihl�en�
    static void MainUserMenu(User user)
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("1. P�idat k�vu");
            Console.WriteLine("2. Zobrazit p�ehled k�vy");
            Console.WriteLine("3. P�idat �kol");
            Console.WriteLine("4. Zobrazit �koly");
            Console.WriteLine("5. Odhl�sit se");
            Console.Write("Vyberte mo�nost: ");
            var choice = Console.ReadLine();

            if (choice == "1")
            {
                AddCoffeeLogMenu(user);
            }
            else if (choice == "2")
            {
                DisplayCoffeeLogs(user);
            }
            else if (choice == "3")
            {
                AddTaskMenu(user);
            }
            else if (choice == "4")
            {
                TaskMenu(user);
            }
            else if (choice == "5")
            {
                break; // Odhl�en�
            }
        }
    }

    // Menu pro p�id�n� k�vy
    static void AddCoffeeLogMenu(User user)
    {
        Console.Clear();
        Console.WriteLine("P�id�n� k�vy:");

        int amount;
        do
        {
            Console.Write("Zadejte mno�stv� vypit�ch k�v: ");
        } while (!int.TryParse(Console.ReadLine(), out amount) || amount <= 0);

        int typeId;
        do
        {
            Console.WriteLine("Zadejte typ k�vy:");
            Console.WriteLine("id\ttype");
            Console.WriteLine("1\tEspresso");
            Console.WriteLine("2\tLungo");
            Console.WriteLine("3\tCappuccino");
            Console.WriteLine("4\tLatte");
            Console.WriteLine("5\tMacchiato");
            Console.WriteLine("6\tMocha");
            Console.WriteLine("7\tAmericano");
            Console.Write("->");
        } while (!int.TryParse(Console.ReadLine(), out typeId) || typeId < 1 || typeId > 7);

        string milk;
        do
        {
            Console.Write("M�te ml�ko? (Ano/Ne): ");
            var input = Console.ReadLine().ToLower();
            if (input == "ano")
            {
                milk = "Ano";
                break;
            }
            else if (input == "ne")
            {
                milk = "Ne";
                break;
            }
        } while (true);

        string sugar;
        do
        {
            Console.Write("M�te cukr? (Ano/Ne): ");
            var input = Console.ReadLine().ToLower();
            if (input == "ano")
            {
                sugar = "Ano";
                break;
            }
            else if (input == "ne")
            {
                sugar = "Ne";
                break;
            }
        } while (true);

        _coffeeLogService.AddCoffeeLog(user.UserId, amount, typeId, milk, sugar);
        Console.WriteLine("K�va byla �sp�n� p�id�na!");

        Console.WriteLine("Stiskn�te libovolnou kl�vesu pro n�vrat.");
        Console.ReadKey();
    }


    // Zobrazen� p�ehledu k�vy
    static void DisplayCoffeeLogs(User user)
    {
        Console.Clear();

        // Na��t�me CoffeeLogs spolu s informacemi o typu k�vy a u�ivateli
        var coffeeLogs = _dbContext.CoffeeLogs
            .Where(cl => cl.UserId == user.UserId)
            .Include(cl => cl.Type) // Na��t�me tabulku CoffeeType
            .Include(cl => cl.User) // Na��t�me tabulku User
            .ToList();

        Console.WriteLine("=== P�ehled k�v ===");
        foreach (var log in coffeeLogs)
        {
            Console.WriteLine($"Zadal: {log.User.Username}| Typ: {log.Type.Type}| Mno�stv�: {log.Amount} k�v| " +
                              $"Ml�ko: {log.Milk}| Cukr: {log.Sugar}| Datum: {log.Timestamp}");
        }
        Console.WriteLine("\nStiskn�te libovolnou kl�vesu pro n�vrat.");
        Console.ReadKey();
    }


    // P�id�n� �kolu
    // P�id�n� �kolu
    static void AddTaskMenu(User user)
    {
        Console.Clear();
        Console.WriteLine("P�id�n� �kolu:");
        Console.Write("Zadejte popis �kolu: ");
        var description = Console.ReadLine();

        // Vytvo�en� nov�ho �kolu
        var task = new CoffeeApp.Models.Task
        {
            Description = description,
            Status = "open", // Status �kolu je na za��tku "Nov�"
            Owner = "Neur�en�"
        };

        // P�id�n� �kolu do datab�ze
        _dbContext.Tasks.Add(task);
        _dbContext.SaveChanges(); // Ulo�en� �kolu a vygenerov�n� TaskId

        // Vytvo�en� vazby mezi u�ivatelem a �kolem (m:n vztah)
        var userTask = new UserTask
        {
            UserId = user.UserId,  // Zde je d�le�it� zajistit, �e user.UserId je platn�
            TaskId = task.TaskId   // Po ulo�en� �kolu je TaskId platn�
        };

        _dbContext.UserTasks.Add(userTask);  // P�id�n� vazby do tabulky UserTask
        _dbContext.SaveChanges(); // Ulo�en� zm�n v datab�zi

        Console.WriteLine("�kol byl �sp�n� p�id�n!");

        Console.WriteLine("Stiskn�te libovolnou kl�vesu pro n�vrat.");
        Console.ReadKey();
    }




    // Zobrazen� �kol�
    static void TaskMenu(User user)
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine($"Moje body: {GetUserPoints(user.UserId)}\n");
            Console.WriteLine("=== Task Menu ===");
            Console.WriteLine("1. Zobrazit nep�i�azen� a nespln�n� �koly");
            Console.WriteLine("2. Zobrazit moje �koly (nespln�n�)");
            Console.WriteLine("3. Vz�t si �kol");
            Console.WriteLine("4. Dokon�it �kol");
            Console.WriteLine("5. Zp�t");
            Console.Write("Vyberte mo�nost: ");

            var choice = Console.ReadLine();
            switch (choice)
            {
                case "1":
                    DisplayUnassignedTasks(user);
                    break;
                case "2":
                    DisplayUserTasks(user);
                    break;
                case "3":
                    AssignTaskToUser(user);
                    break;
                case "4":
                    CompleteTask(user);
                    break;
                case "5":
                    return;
                default:
                    Console.WriteLine("Neplatn� volba. Stiskn�te libovolnou kl�vesu a zkuste to znovu.");
                    Console.ReadKey();
                    break;
            }
        }
    }

    static int GetUserPoints(int userId)
    {
        var rewards = _dbContext.Rewards.FirstOrDefault(r => r.UserId == userId);
        return rewards?.Points ?? 0;
    }


    static void DisplayUnassignedTasks(User user)
    {
        Console.Clear();
        var tasks = _dbContext.Tasks
            .Where(t => t.Status == "open" && (t.Owner == null || t.Owner != user.Username))
            .ToList();

        Console.WriteLine("=== Nep�i�azen� a nespln�n� �koly ===");
        for (int i = 0; i < tasks.Count; i++)
        {
            Console.WriteLine($"{i + 1}. �kol: {tasks[i].Description}, Status: {tasks[i].Status}, Vlastn�k: {(tasks[i].Owner ?? "Nezn�m�")}");
        }

        Console.WriteLine("\nStiskn�te libovolnou kl�vesu pro n�vrat.");
        Console.ReadKey();
    }

    static void DisplayUserTasks(User user)
    {
        Console.Clear();
        var tasks = _dbContext.Tasks
            .Where(t => t.Status == "open" && t.Owner == user.Username)
            .ToList();

        Console.WriteLine("=== Moje �koly ===");
        for (int i = 0; i < tasks.Count; i++)
        {
            Console.WriteLine($"{i + 1}. �kol: {tasks[i].Description}, Status: {tasks[i].Status}");
        }

        Console.WriteLine("\nStiskn�te libovolnou kl�vesu pro n�vrat.");
        Console.ReadKey();
    }

    static void AssignTaskToUser(User user)
    {
        Console.Clear();
        var tasks = _dbContext.Tasks
            .Where(t => t.Status == "open")
            .ToList();

        Console.WriteLine("=== Dostupn� �koly ===");
        for (int i = 0; i < tasks.Count; i++)
        {
            Console.WriteLine($"{i + 1}. �kol: {tasks[i].Description}, Vlastn�k: {(tasks[i].Owner ?? "Nezn�m�")}");
        }

        Console.Write("\nZadejte ��slo �kolu, kter� chcete p�i�adit: ");
        if (int.TryParse(Console.ReadLine(), out int taskNumber) && taskNumber > 0 && taskNumber <= tasks.Count)
        {
            var selectedTask = tasks[taskNumber - 1];
            selectedTask.Owner = user.Username;
            _dbContext.SaveChanges();
            Console.WriteLine("�kol byl �sp�n� p�i�azen v�m. Stiskn�te libovolnou kl�vesu pro n�vrat.");
        }
        else
        {
            Console.WriteLine("Neplatn� vstup. Stiskn�te libovolnou kl�vesu a zkuste to znovu.");
        }

        Console.ReadKey();
    }

    static void CompleteTask(User user)
    {
        Console.Clear();
        var tasks = _dbContext.Tasks
            .Where(t => t.Status == "open" && t.Owner == user.Username)
            .ToList();

        Console.WriteLine("=== Moje �koly ===");
        for (int i = 0; i < tasks.Count; i++)
        {
            Console.WriteLine($"{i + 1}. �kol: {tasks[i].Description}");
        }

        Console.Write("\nZadejte ��slo �kolu, kter� chcete dokon�it: ");
        if (int.TryParse(Console.ReadLine(), out int taskNumber) && taskNumber > 0 && taskNumber <= tasks.Count)
        {
            var selectedTask = tasks[taskNumber - 1];
            selectedTask.Status = "complete";

            // P�id�n� bod� u�ivateli
            var reward = _dbContext.Rewards.FirstOrDefault(r => r.UserId == user.UserId);
            if (reward != null)
            {
                reward.Points += 10; // P�id�v�me pevn� 10 bod� za �kol
                reward.LastUpdated = DateTime.Now;
            }
            else
            {
                _dbContext.Rewards.Add(new Reward
                {
                    UserId = user.UserId,
                    Points = 10,
                    LastUpdated = DateTime.Now
                });
            }

            _dbContext.SaveChanges();
            Console.WriteLine("�kol byl �sp�n� dokon�en a body p�id�ny. Stiskn�te libovolnou kl�vesu pro n�vrat.");
        }
        else
        {
            Console.WriteLine("Neplatn� vstup. Stiskn�te libovolnou kl�vesu a zkuste to znovu.");
        }

        Console.ReadKey();
    }

}
