﻿using CoffeeApp.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
namespace CoffeeApp.Models
{
    public class User
    {
        [Key]
        [Column("users_id")]
        public int UserId { get; set; }

        [Column("username")]
        [Required]
        [MaxLength(100)]
        public string Username { get; set; }

        [Column("password")]
        [Required]
        [MaxLength(254)]
        public string Password { get; set; }

        [Column("registerd_at")]
        public DateTime RegisteredAt { get; set; } = DateTime.Now;

        public ICollection<CoffeeLog> CoffeeLogs { get; set; }
        public ICollection<UserTask> UserTasks { get; set; }  // Správa mnoha na mnoho vztahu
        public ICollection<Reward> Rewards { get; set; }
    }
}