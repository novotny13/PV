﻿using System.ComponentModel.DataAnnotations.Schema;
namespace CoffeeApp.Models
{
    public class UserTask
    {
        [ForeignKey(nameof(User))]
        [Column("user_id")]
        public int UserId { get; set; }

        public User User { get; set; }

        [ForeignKey(nameof(Task))]
        [Column("task_id")]
        public int TaskId { get; set; }

        public Task Task { get; set; }

        [Column("assigned_at")]
        public DateTime AssignedAt { get; set; } = DateTime.Now;
    }
}