﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CoffeeApp.Models
{
    [Table("rewards")]
    public class Reward
    {
        [Key]
        [Column("reward_id")]
        public int RewardId { get; set; }

        [Column("user_id")]
        [Required]
        public int UserId { get; set; }

        [Column("points")]
        [Required]
        public int Points { get; set; }

        [Column("last_updated")]
        [Required]
        public DateTime LastUpdated { get; set; }

        public User User { get; set; }
    }
}
