﻿using System.Linq;
using CoffeeApp.Data;
using CoffeeApp.Models;

namespace CoffeeApp.Services
{
    public class CoffeeLogService
    {
        private readonly AppDbContext _dbContext;

        public CoffeeLogService(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void AddCoffeeLog(int userId, int amount, int typeId, string milk, string sugar)
        {
            _dbContext.CoffeeLogs.Add(new CoffeeLog
            {
                UserId = userId,
                Amount = amount,
                TypeId = typeId,
                Milk = milk ,
                Sugar = sugar 
            });
            _dbContext.SaveChanges();
        }
    }
}
