﻿using System;
using System.Linq;
using CoffeeApp.Data;
using CoffeeApp.Models;

namespace CoffeeApp.Services
{
    public class UserService
    {
        private readonly AppDbContext _dbContext;

        public UserService(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public bool RegisterUser(string username, string password)
        {
            if (_dbContext.Users.Any(u => u.Username == username))
                return false;

            var hashedPassword = HashPassword(password);
            _dbContext.Users.Add(new User
            {
                Username = username,
                Password = hashedPassword
            });
            _dbContext.SaveChanges();
            return true;
        }

        public User LoginUser(string username, string password)
        {
            var hashedPassword = HashPassword(password);
            return _dbContext.Users.FirstOrDefault(u => u.Username == username && u.Password == hashedPassword);
        }

        private string HashPassword(string password)
        {
            using (var sha256 = System.Security.Cryptography.SHA256.Create())
            {
                var bytes = System.Text.Encoding.UTF8.GetBytes(password);
                var hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }

        
    }

}
