﻿using CoffeeApp.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
namespace CoffeeApp.Models
{
    public class Task
    {
        [Key]
        [Column("id")]
        public int TaskId { get; set; }

        [Column("description")]
        [Required]
        [MaxLength(255)]
        public string Description { get; set; }

        [Column("status")]
        [Required]
        [MaxLength(50)]
        public string Status { get; set; }

        [Column("owner")]
        [Required]
        [MaxLength(255)]
        public string Owner { get; set; }

        public ICollection<UserTask> UserTasks { get; set; }  // Správa mnoha na mnoho vztahu
    }
}